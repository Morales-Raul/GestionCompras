import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:clase_4/models/product.dart';

class ProductsService extends ChangeNotifier {
  final List<Product> _allProducts = [];
  bool isLoading = true;
  bool isSaving = false;

  late Product selectedProduct;

  String _selectedCategory = 'Todos';

  String get selectedCategory => _selectedCategory;

  List<Product> get products {
    if (_selectedCategory == 'Todos') return _allProducts;
    return _allProducts
        .where(
            (p) => p.category.toLowerCase() == _selectedCategory.toLowerCase())
        .toList();
  }

  ProductsService() {
    loadProducts();
  }

  Future loadProducts() async {
    isLoading = true;
    notifyListeners();

    final url = Uri.https(
      'baseflutterumg-default-rtdb.firebaseio.com',
      'productos.json',
    );
    final response = await http.get(url);

    if (response.statusCode != 200) {
      isLoading = false;
      notifyListeners();
      return;
    }

    final data = json.decode(response.body);

    _allProducts.clear();

    // Si es un List (cuando los keys son 0, 1, 2...)
    if (data is List) {
      for (int i = 0; i < data.length; i++) {
        if (data[i] != null) {
          final product = Product(
            id: i.toString(),
            name: data[i]['name'],
            category: data[i]['category'],
            imageUrl: data[i]['imageUrl'],
            available: data[i]['available'],
            prices: Map<String, double>.from(
              (data[i]['prices'] as Map).map(
                (k, v) => MapEntry(k, double.parse(v.toString())),
              ),
            ),
          );
          _allProducts.add(product);
        }
      }
    }

    selectedProduct = _allProducts.isNotEmpty
        ? _allProducts.first
        : Product(
            id: '',
            name: '',
            category: '',
            imageUrl: '',
            available: true,
            prices: {},
          );

    isLoading = false;
    notifyListeners();
  }

  Future<void> saveOrCreateProduct(Product product) async {
    isSaving = true;
    notifyListeners();

    final productData = {
      'name': product.name,
      'category': product.category,
      'imageUrl': product.imageUrl,
      'available': product.available,
      'prices': product.prices,
    };

    final url = Uri.https(
      'baseflutterumg-default-rtdb.firebaseio.com',
      'productos.json',
    );
    await http.post(url, body: json.encode(productData));

    await loadProducts(); // Refrescar productos luego de guardar

    isSaving = false;
    notifyListeners();
  }

  Future<String?> uploadImage(File image) async {
    await Future.delayed(Duration(seconds: 2));
    return 'https://fakeurl.com/images/${image.path.split('/').last}';
  }

  void selectCategory(String category) {
    _selectedCategory = category;
    notifyListeners();
  }

  void updateSelectedProductImage(String newImageUrl) {
    selectedProduct = selectedProduct.copy();
    selectedProduct.imageUrl = newImageUrl;
    notifyListeners();
  }

  void updateSelectedProduct(Product updatedProduct) {
    selectedProduct = updatedProduct;
    notifyListeners();
  }
}
