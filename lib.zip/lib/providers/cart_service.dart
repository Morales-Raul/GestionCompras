import 'package:flutter/material.dart';
import 'package:clase_4/models/product.dart';

class CartService extends ChangeNotifier {
  List<Product> _products = [];

  // Supermercado seleccionado para comprar
  String _selectedStore = 'Walmart';

  List<Product> get products => _products;

  String get selectedStore => _selectedStore;

  void addProduct(Product product) {
    _products.add(product);
    notifyListeners();
  }

  void removeProduct(Product product) {
    _products.remove(product);
    notifyListeners();
  }

  void clearCart() {
    _products.clear();
    notifyListeners();
  }

  // Cambiar supermercado seleccionado
  void selectStore(String store) {
    if (_selectedStore != store) {
      _selectedStore = store;
      notifyListeners();
    }
  }

  // Obtener totales por supermercado
  Map<String, double> getTotalBySupermarket() {
    Map<String, double> totals = {
      'Walmart': 0,
      'PriceSmart': 0,
      'La Torre': 0,
    };

    for (var product in _products) {
      product.prices.forEach((supermarket, price) {
        totals[supermarket] = (totals[supermarket] ?? 0) + price;
      });
    }
    return totals;
  }

  // Total según supermercado seleccionado
  double calculateTotalPrice() {
    double total = 0;
    for (var product in _products) {
      total += product.prices[_selectedStore] ?? 0;
    }
    return total;
  }

  String getCheapestSupermarket() {
    final totals = getTotalBySupermarket();
    String cheapest = totals.keys.first;
    double minPrice = totals[cheapest]!;

    totals.forEach((supermarket, price) {
      if (price < minPrice) {
        cheapest = supermarket;
        minPrice = price;
      }
    });
    return cheapest;
  }
}
