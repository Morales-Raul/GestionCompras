import 'package:clase_4/screens/CompraFinalizadaScreen.dart';
import 'package:clase_4/screens/FormularioCompraScreen.dart';
import 'package:clase_4/screens/carne_screen.dart';
import 'package:clase_4/screens/dispositivos_screen.dart';
import 'package:clase_4/screens/higiene_screen.dart';
import 'package:clase_4/screens/licores_screen.dart';
import 'package:clase_4/screens/ropa_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:clase_4/screens/login_screen.dart';
import 'package:clase_4/screens/home_screen.dart';
import 'package:clase_4/screens/product_screen.dart';
import 'package:clase_4/screens/carrito_screen.dart';
import 'package:clase_4/screens/perfil_screen.dart';

import 'package:clase_4/services/products_service.dart';
import 'package:clase_4/providers/cart_service.dart'; // Asegúrate de tener este archivo

import 'package:clase_4/models/product.dart'; // Importa tu modelo Product si está separado

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ProductsService()),
        ChangeNotifierProvider(create: (_) => CartService()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Comparador de Precios',
        initialRoute: 'home',
        routes: {
          'login': (_) => LoginScreen(),
          'home': (_) => HomeScreen(),
          //'product': (_) => ProductScreen(),  // <-- Eliminado para manejar con onGenerateRoute
          'carrito': (_) => CarritoScreen(),
          'perfil': (_) => PerfilScreen(),
          'carne': (_) => CarneScreen(),
          'ropa': (_) => RopaScreen(),
          'dispositivos': (_) => DispositivosScreen(),
          'licores': (_) => LicoresScreen(),
          'higiene': (_) => HigieneScreen(),
          'formularioCompra': (context) => FormularioCompraScreen(),
          'compraFinalizada': (context) => CompraFinalizadaScreen(),
        },
        onGenerateRoute: (settings) {
          if (settings.name == 'product') {
            final product = settings.arguments as Product;
            return MaterialPageRoute(
              builder: (_) => ProductScreen(product: product),
            );
          }
          return null; // Si no coincide, usa rutas definidas en routes
        },
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: Colors.indigo,
        ),
      ),
    );
  }
}
