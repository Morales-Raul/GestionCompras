import 'package:clase_4/providers/cart_service.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CarritoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final cartService = Provider.of<CartService>(context);

    final totals = cartService.getTotalBySupermarket();
    final selectedStore = cartService.selectedStore;
    final cartProducts = cartService.products;

    return Scaffold(
      appBar: AppBar(
        title: Text('Carrito de Compra'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Lista de supermercados con total y selección
            Text(
              'Selecciona el supermercado para la compra:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: totals.keys.map((store) {
                final isSelected = store == selectedStore;
                return GestureDetector(
                  onTap: () {
                    cartService.selectStore(store);
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                    decoration: BoxDecoration(
                      color: isSelected ? Colors.indigo : Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      children: [
                        Text(
                          store,
                          style: TextStyle(
                            color: isSelected ? Colors.white : Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 6),
                        Text(
                          '\$${totals[store]!.toStringAsFixed(2)}',
                          style: TextStyle(
                            color: isSelected ? Colors.white : Colors.black,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),

            const SizedBox(height: 20),

            // Lista de productos en el carrito
            Expanded(
              child: cartProducts.isEmpty
                  ? Center(child: Text('No hay productos en el carrito.'))
                  : ListView.builder(
                      itemCount: cartProducts.length,
                      itemBuilder: (context, index) {
                        final product = cartProducts[index];
                        final price = product.prices[selectedStore] ?? 0.0;

                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 6),
                          child: ListTile(
                            title: Text(product.name),
                            subtitle: Text('Precio en $selectedStore: \$${price.toStringAsFixed(2)}'),
                            trailing: IconButton(
                              icon: Icon(Icons.delete, color: Colors.red),
                              onPressed: () {
                                cartService.removeProduct(product);
                              },
                            ),
                          ),
                        );
                      },
                    ),
            ),

            const SizedBox(height: 16),

            // Mostrar total según supermercado seleccionado
            Text(
              'Total a pagar en $selectedStore:',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            Text(
              '\$${cartService.calculateTotalPrice().toStringAsFixed(2)}',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.indigo),
            ),

            const SizedBox(height: 16),

            // Botón continuar
            ElevatedButton.icon(
              icon: Icon(Icons.arrow_forward),
              label: Text('Continuar al formulario de compra'),
              style: ElevatedButton.styleFrom(
                minimumSize: Size(double.infinity, 50),
              ),
              onPressed: () {
                if (cartService.products.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('El carrito está vacío')),
                  );
                  return;
                }
                Navigator.pushNamed(context, 'formularioCompra');
              },
            ),
          ],
        ),
      ),
    );
  }
}
