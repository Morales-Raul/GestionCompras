import 'package:clase_4/providers/cart_service.dart';
import 'package:clase_4/screens/dispositivos_screen.dart';
import 'package:clase_4/screens/higiene_screen.dart';
import 'package:clase_4/screens/licores_screen.dart';
import 'package:clase_4/screens/ropa_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:clase_4/services/products_service.dart';
import 'package:clase_4/screens/carne_screen.dart'; // Asegúrate de importar tu screen

class HomeScreen extends StatelessWidget {
  final List<Map<String, dynamic>> categories = [
    {'emoji': '🥩', 'label': 'Carne', 'route': CarneScreen()},
    {'emoji': '📱', 'label': 'Dispositivos', 'route': DispositivosScreen()},
    {'emoji': '👗', 'label': 'Ropa', 'route': RopaScreen()},
    {'emoji': '🧼', 'label': 'Higiene', 'route': HigieneScreen()},
    {'emoji': '🍷', 'label': 'Licores', 'route': LicoresScreen()},
  ];

  @override
  Widget build(BuildContext context) {
    final cartService = Provider.of<CartService>(context);
    final productsService = Provider.of<ProductsService>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Encuentra tus productos'),
        actions: [
          Stack(
            children: [
              IconButton(
                icon: Icon(Icons.shopping_cart),
                onPressed: () {
                  Navigator.pushNamed(context, 'carrito');
                },
              ),
              if (cartService.products.isNotEmpty)
                Positioned(
                  right: 6,
                  top: 6,
                  child: CircleAvatar(
                    backgroundColor: Colors.red,
                    radius: 10,
                    child: Text(
                      cartService.products.length.toString(),
                      style: TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ),
                ),
            ],
          ),
          IconButton(
            icon: Icon(Icons.account_circle),
            onPressed: () {
              Navigator.pushNamed(context, 'perfil');
            },
          ),
        ],
      ),
      drawer: _Sidebar(),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            // 🔍 Barra de búsqueda
            TextField(
              decoration: InputDecoration(
                hintText: 'Buscar productos...',
                prefixIcon: Icon(Icons.search),
                filled: true,
                fillColor: Colors.grey[100],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
              ),
              onChanged: (value) {
                print('Buscando: $value');
                // Aquí puedes implementar la lógica para filtrar productos
              },
            ),
            SizedBox(height: 16),

            // 🟦 Categorías en forma de rejilla
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                children: categories.map((cat) {
                  final bool isSelected =
                      productsService.selectedCategory == cat['label'];
                  return GestureDetector(
                    onTap: () {
                      productsService.selectCategory(cat['label']);
                      if (cat['route'] != null) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => cat['route']),
                        );
                      }
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: isSelected ? Colors.indigo[200] : Colors.indigo[50],
                        borderRadius: BorderRadius.circular(16),
                        border: isSelected
                            ? Border.all(color: Colors.indigo, width: 2)
                            : null,
                      ),
                      padding: EdgeInsets.all(12),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(cat['emoji'], style: TextStyle(fontSize: 36)),
                          SizedBox(height: 12),
                          Text(
                            cat['label'],
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w600),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Sidebar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          DrawerHeader(
            decoration: BoxDecoration(color: Colors.indigo),
            child: Center(
              child: Text(
                'Categorías',
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
          ),
          _drawerItem(context, '🥩 Carne', 'Carne', CarneScreen()),
          _drawerItem(context, '📱 Dispositivos', 'Dispositivos', DispositivosScreen()),
          _drawerItem(context, '👗 Ropa', 'Ropa', RopaScreen()),
          _drawerItem(context, '🧼 Higiene', 'Higiene', HigieneScreen()),
          _drawerItem(context, '🍷 Licores', 'Licores', LicoresScreen()),
          Spacer(),
          Divider(),
          ListTile(
            leading: Icon(Icons.logout, color: Colors.red),
            title: Text('Cerrar sesión'),
            onTap: () {
              Navigator.pushReplacementNamed(context, 'login');
            },
          ),
        ],
      ),
    );
  }

  Widget _drawerItem(
      BuildContext context, String title, String category, Widget? screen) {
    return ListTile(
      title: Text(title),
      onTap: () {
        final productsService =
            Provider.of<ProductsService>(context, listen: false);
        productsService.selectCategory(category);
        Navigator.pop(context);
        if (screen != null) {
          Navigator.push(
              context, MaterialPageRoute(builder: (_) => screen));
        }
      },
    );
  }
}
