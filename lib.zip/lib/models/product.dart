class Product {
  String id;
  String name;
  String imageUrl;
  String category;
  bool available;

  // Mapa de precios por supermercado
  Map<String, double> prices;

  Product({
    required this.id,
    required this.name,
    required this.imageUrl,
    required this.category,
    required this.prices,
    this.available = true,
  });

  // Factory para crear instancia desde un mapa (Firebase)
  factory Product.fromMap(Map<String, dynamic> map, String documentId) {
    return Product(
      id: documentId,
      name: map['name'] ?? '',
      imageUrl: map['imageUrl'] ?? '',
      category: map['category'] ?? '',
      available: map['available'] ?? true,
      prices: {
        'Walmart': _toDouble(map['walmartPrice']),
        'PriceSmart': _toDouble(map['priceSmartPrice']),
        'La Torre': _toDouble(map['laTorrePrice']),
      },
    );
  }

  // Convierte la instancia a un mapa para guardar en Firebase
  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'imageUrl': imageUrl,
      'category': category,
      'walmartPrice': prices['Walmart'] ?? 0.0,
      'priceSmartPrice': prices['PriceSmart'] ?? 0.0,
      'laTorrePrice': prices['La Torre'] ?? 0.0,
      'available': available,
    };
  }

  // Crea una copia del producto
  Product copy() => Product(
        id: id,
        name: name,
        imageUrl: imageUrl,
        category: category,
        prices: Map<String, double>.from(prices),
        available: available,
      );

  // Helper para convertir dinámicos a double
  static double _toDouble(dynamic value) {
    if (value is int) return value.toDouble();
    if (value is double) return value;
    if (value is String) return double.tryParse(value) ?? 0.0;
    return 0.0;
  }
}
